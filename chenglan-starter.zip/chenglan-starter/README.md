# 澄蓝 · AI 伴侣（起步版）

本仓库从零开始，前端使用 HTML/CSS/JavaScript，使用 Capacitor 包装为 Android 应用，并通过 GitHub Actions 云端构建 APK。

## 当前包含
- 澄蓝界面原型：聊天、音乐、工具中心、伴侣记忆与设置
- 可切换背景，不固定星空壁纸
- 记忆文件选择/预览能力（当前不自动合并导入）

## 云端构建 APK
1. 将本项目文件上传到仓库的 `main` 分支，保留 `.github/workflows/android-apk.yml` 路径。
2. 打开仓库的 **Actions** 标签；若 GitHub 要求启用 Actions，请启用。
3. 选择 **Build Android APK**，点击 **Run workflow**；也可通过 push 自动触发。
4. 等待运行结束，打开该次运行页面，在 **Artifacts** 下载 `chenglan-debug-apk` ZIP。
5. 在 Android 手机上解压 ZIP，安装 `app-debug.apk`。安装时可能需要允许从该来源安装应用。

## 重要说明
这是起步版，尚未接入真实 AI 模型、网易云音乐登录/播放、插件/MCP 后端或云端记忆同步。不要将 API Key 写进前端或提交到仓库；后续应使用安全的后端服务。
